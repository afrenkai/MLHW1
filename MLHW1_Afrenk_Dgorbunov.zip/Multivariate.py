##############################
# Part 1
##############################
# Write your answers to the math problems below. To represent exponents, use the ^ symbol.
# 1.
#dh/dx = yz^2 +2y -z
#dh/dy = xz^2 + 2x
#dh/dz = 2xyz-x
# 2.
# dg/du = d/du(u sinv + log(v^2)) = sin v
# sg/dv = d / dv(u sinv + log(v^2)) d / dv log (v^2) = u cos v. d/dv log (v^2) = 1 / v^2 * 2v = 2v / v ^2 = 2/v = ucosv + 2/v
# 3.
# B must be 3 x 7
# 4.
# QR = [[4x+y], [2x+y], [0]]
#p^TQr = [-1 1 -3][[4x + y]. [2x + y][0]]
#g(x, y) = -1(4x + y) + 1(2x + y) + (-3)(0)
#g(x,y) = -4x - y +2x +y
#g(x ,y) = -2x
#dg/dx \ d(-2x) / dx = -2
#d(g)/dy = d(-2x)/dy = 0